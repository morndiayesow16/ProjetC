#include<stdio.h>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
#include<windows.h>
#include<math.h>

int main(){
    int i,y,x,choix,z;
    char rep;
    do{
        system("cls");system("color d");
        for(z=0;z<101;z++){
        gotoxy(5,2);gotoxy(5,0);printf("CHARGEMENT..... %d  %%",z);Sleep(20);
        }
     system("cls");
     system("color 0C");

     printf("\n\n\t\tB");Sleep(60);printf("I");Sleep(60);printf("E");Sleep(60);printf("N");Sleep(60);printf("V");Sleep(60);
     printf("E");Sleep(60);printf("N");Sleep(60);printf("U");Sleep(60);printf("E");Sleep(60);printf(" D");Sleep(60);
     printf("A");Sleep(60);printf("N");Sleep(60);printf("S");Sleep(60);printf(" N");Sleep(60);
     printf("O");Sleep(60);printf("T");Sleep(60);printf("R");Sleep(60);printf("E");Sleep(60);
     printf(" A");Sleep(60);printf("P");Sleep(60);printf("P");Sleep(60);printf("L");Sleep(60);
     printf("I");Sleep(60);printf("C");Sleep(60);printf("A");Sleep(60);printf("T");Sleep(60);
     printf("I");Sleep(300);printf("O");Sleep(60);printf("N");Sleep(60);printf(" M");Sleep(60);
     printf("R");Sleep(60);printf(" &");Sleep(60);
     printf(" M");Sleep(60);
     printf("m");Sleep(60);
     printf("e");Sleep(60);
     printf("\n\n\n");
    printf("\t\t\t        *MENU GENERAL*\n");
    printf("\t\t\t        _______________\n\n");
    printf("\t        _________________________     ________________________         \n");Sleep(100);
    printf("\t*------<                          >-<                          >------*\n");Sleep(100);
    printf("\t|------<                          >-<                          >------|\n");Sleep(100);
    printf("\t|------< 01: EXO SIMPLES          >-<  02: TABLEAUX & MATRICES >------|\n");Sleep(100);
    printf("\t|------<                          >-<                          >------|\n");Sleep(100);
    printf("\t*------<_________________________ >-< ________________________ >------*\n");Sleep(100);

     printf("\n\n\tPOUR");Sleep(100);printf(" QUITTER");Sleep(100);printf(" CETTE");Sleep(100);printf(" PAGE");Sleep(100);
     printf(" APPUYER");Sleep(100);printf(" SUR");Sleep(100);printf(" ZERO\n\n");Sleep(100);

     printf("\tF");Sleep(60);printf("A");Sleep(60);printf("I");Sleep(60);printf("T");Sleep(60);
     printf("E");Sleep(60);printf("S");Sleep(60);printf(" V");Sleep(60);printf("O");Sleep(60);
     printf("T");Sleep(60);printf("R");Sleep(60);printf("E");Sleep(60);printf(" C");Sleep(60);
     printf("H");Sleep(60);printf("O");Sleep(60);printf("I");Sleep(60);printf("X ");Sleep(60);

    while(scanf("%d",&choix)!=1){
    printf("choisissez parmis ces numero du menu");
    getchar();
    }

    switch(choix){
        case 1:do{
                system("cls");
                system("color 0c");

                int choix;
    char rep;
    do{
     system("cls");
     system("color 0c");
     printf("\n\n\t\tB");Sleep(60);printf("I");Sleep(60);printf("E");Sleep(60);printf("N");Sleep(60);printf("V");Sleep(60);
     printf("E");Sleep(60);printf("N");Sleep(60);printf("U");Sleep(60);printf("E");Sleep(60);printf(" D");Sleep(60);
     printf("A");Sleep(60);printf("N");Sleep(60);printf("S");Sleep(60);printf(" N");Sleep(60);
     printf("O");Sleep(60);printf("T");Sleep(60);printf("R");Sleep(60);printf("E");Sleep(60);
     printf(" A");Sleep(60);printf("P");Sleep(60);printf("P");Sleep(60);printf("L");Sleep(60);
     printf("I");Sleep(60);printf("C");Sleep(60);printf("A");Sleep(60);printf("T");Sleep(60);
     printf("I");Sleep(300);printf("O");Sleep(60);printf("N");Sleep(60);printf(" M");Sleep(60);
     printf("R");Sleep(60);printf(" &");Sleep(60);
     printf(" M");Sleep(60);
     printf("R");Sleep(60);
     printf("s");Sleep(60);
    printf("\n\n\n");
    printf("\t\t\t       *MENU DES EXO SIMPLES*\n");
    printf("\t\t\t       _______________________\n");
    printf("\t        _________________________     ________________________         \n");Sleep(100);
    printf("\t*------<                          >-<                          >------*\n");Sleep(100);
    printf("\t|------< 01: AGES                 >-<  09: EXO DEVINETTE       >------|\n");Sleep(100);
    printf("\t|------< 02: FACTORIEL            >-<  10: EXO FIBONACCI       >------|\n");Sleep(100);
    printf("\t|------< 03: PGCD DE 2 NOMBRES    >-<  11: EQUATION 1 DEGRE    >------|\n");Sleep(100);
    printf("\t|------< 04: PPCM DE 2 NOMBRES    >-<  12: EQUATION 2ND DEGRE  >------|\n");Sleep(100);
    printf("\t|------< 05: CLANDRIER MENSUEL    >-<  13: NOMBRE PARFAIT      >------|\n");Sleep(100);
    printf("\t|------< 06: MOYENNE GENERALE     >-<  14: NOMBRE PREMIER      >------|\n");Sleep(100);
    printf("\t|------< 07: CLANDRIER ANNUEL     >-<  15: MULTIPLE DUN NOMBRE >------|\n");Sleep(100);
    printf("\t|------< 08: LES TRIANGLES        >-<                          >------|\n");Sleep(100);
    printf("\t*------<_________________________ >-< _________________________>------*\n");Sleep(100);

   printf("\n\n\tPOUR");Sleep(60);printf(" QUITTER");Sleep(60);printf(" CETTE");Sleep(60);printf(" PAGE");Sleep(60);
     printf(" APPUYER");Sleep(60);printf(" SUR");Sleep(60);printf(" ZERO\n\n");Sleep(60);

   printf("\tF");Sleep(60);printf("A");Sleep(60);printf("I");Sleep(60);printf("T");Sleep(60);
     printf("E");Sleep(60);printf("S");Sleep(60);printf(" V");Sleep(60);printf("O");Sleep(60);
     printf("T");Sleep(60);printf("R");Sleep(60);printf("E");Sleep(60);printf(" C");Sleep(60);
     printf("H");Sleep(60);printf("O");Sleep(60);printf("I");Sleep(60);printf("X ");Sleep(60);

    while(scanf("%d",&choix)!=1){
    printf("choisissez parmis ces numero du menu");
    getchar();}

    switch(choix){
        case 1:do{
                system("cls");
                system("color 0c");
                printf("_________________________BIENVENUE DANS L'EXO DES AGES__________________________\n");Sleep(200);

                 int A;
                 printf("\nEntrez l'Age de l'Enfant:");Sleep(200);
                 while(scanf("%d",&A)!=1){
                 printf("saisir seulement des chiffres");
                 getchar();
                 }
                 if(A>=12){
                 printf("Categorie Cadet\n\n");
                 }
                 else if(A>=10){
                  printf("Categorie Minime\n\n");
                 }
                  else if(A>=8){
                     printf("Categorie Pupille\n\n");
                  }
                   else if(A>=6){
                    printf("Categorie Poussin\n\n");
                   }
                   else if(A<6){
                    printf("Categorie BEBE\n\n");
                   }

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 2:do{
                system("cls");
                 system("color 0c");

                printf("\n****************BIENVENUE DANS L'EXO FACTORIEL ET LA PUISSANCE******************");Sleep(200);
                printf("\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
                int n,i,p,j,k ,f=1;
                printf("saisir le nombre \n");
                while(scanf("%d",&n)!=1){
                    printf("Veuillez saisir des chiffres ");Sleep(200);
                    getchar();
                }
                if(n==0){
                  printf("le factoriel est 1\n");}
                else{
                 for(i=1; i<=n; i++){
                  f=f*i;}
                  printf("le factoriel est %d \n\n",f);
                  }
                  printf("saisir la puissance \n");
                  while(scanf("%d",&p)!=1){
                    printf("Veuillez saisir des chiffres ");Sleep(200);
                    getchar();
                }
                   if(n>0)
                    if(p==0){
                    printf("la puissance est 1");}
                    else if(p==1){
                    printf("la puissance est %d\n\n",n);}
                   else{
                       k=n;
                    for(j=1; j<p; j++){
                          n=n*k;}
                    printf("la puissance est %d\n",n);
                }
                  else{
                   printf("indetermination\n");
            }
                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 3:do{
                system("cls");
                system("color 0c");
                printf("____________________________***Bienvenue PGCD***______________________________\n\n");

                 int a,b,h;
                do{
                printf("saisir un chiffre ");Sleep(200);
                while(scanf("%d",&a)!=1){
                printf("saisissez un chiffre ");
                getchar();}
                printf("saisir un deuxieme chiffre ");Sleep(200);
                while(scanf("%d",&b)!=1){
                printf("saisissez un chiffre ");
                getchar();}
                }while(a<0||b<0);
                if(a>b)
                    h=a;
                else{
                     h=b;
                    }
                while(a%h!=0||b%h!=0){
                  h=h-1;}
                printf("le pgcd est %d",h);
                printf("\ncontinuer o/n: ");
                rep=getch();

                }while(rep!='n' && rep!='N');break;/*exo ok*/
        case 4:do{
                system("cls");
                system("color 0c");
                printf("____________________________***BIENVENUE PPCM****______________________________\n\n");

                int a,b,sb,sa;
                 do{
                  printf("saisir le premier nombre ");
                  while(scanf("%d",&a)!=1){
                  printf("saisisser un chiffre");
                  getchar();}
                  printf("saisir le deuxieme nombre");
                  while(scanf("%d",&b)!=1){
                   printf("saisissez un chiffre");
                   getchar();}
                 }
                 while(a<=0|| b<=0);
                      sa=a;
                      sb=b;
                 while(sa!=sb){
                   if(sa>sb){
                      sb+=b;
                }
                   else{
                      sa+=a;
                     }
                } printf("le ppcm est %d", sa);


                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 5:do{
                system("cls");
                printf("\n\t________________________CLANDRIER MENSUEL___________________________\n");
                int mois,jourmax,annee,jour,m1,a1,as,ns,f,ac=0,a,i,j,c,p;
                system("color 3");
                do
                 {
                  printf("\tDonner le mois: ");
                  while(scanf("%d",&mois)!=1){
                  printf("\tsaisisser des chiffres ");
                  getchar();
                  }
                }
                 while ((mois<1) || (mois>12));
                {
                 printf("\tDonner l'annee: ");
                 while(scanf("%d",&annee)!=1){
                 printf("\tsaisisser des chiffres ");
                  getchar();
                  }
                  }

                  if (mois==2)
                {
                 if (((annee%4==0) && (annee%100!=0)) || ((annee%400==0) && (annee%100==0)))
                    jourmax=29;
                 else
                         jourmax=28;
                     }
                      else
                          {
                          if ((mois==1) || (mois==3) || (mois==5) || (mois==7) || (mois==8) || (mois==10) || (mois==10))
                                 jourmax=31;
                          if ((mois==4) || (mois==6) || (mois==9) || (mois==11))
                                  jourmax=30;
                           }

                            jour=1;
                           if (mois>=3)
                           {
                                 m1 = mois - 2;
                                 a1 = annee;

                            }
                             else
                                 {
                                   m1 = mois + 10;
                                   a1 = annee -1;
                                  }
                                       ns= (a1 / 100);
                                      as= (a1 % 100);
                                      f= (jour + as + as/4 - 2*ns + ns/4 + (26*m1-2)/10);
                                      a = (f % 7);
                            printf("\n\nCALENDRIER MENSUEL:\n\n");
                            if(mois==1)
                                 printf("\tJANVIER/%d\n",annee);
                            if(mois==2)
                               printf("\tFEVRIER/%d\n\n",annee);
                            if(mois==3)
                                 printf("\tMARS/%d\n\n",annee);
                            if(mois==4)
                               printf("\tAVRIL/%d\n\n",annee);
                                    if(mois==5)
                               printf("\tMAI/%d\n\n",annee);
                            if(mois==6)
                               printf("\tJUIN/%d\n\n",annee);
                            if(mois==7)
                                printf("\tJUILLET/%d\n\n",annee);
                            if(mois==8)
                              printf("\tAOUT/%d\n\n",annee);
                            if(mois==9)
                               printf("\tSEPTEMBRE/%d\n\n",annee);
                            if(mois==10)
                                  printf("\tOCTOBRE/%d\n\n",annee);
                            if(mois==11)
                               printf("\tNOVEMBRE/%d\n\n",annee);
                            if(mois==12)
                                printf("\tDECEMBRE/%d\n\n",annee);
                                printf("\n");
                             if (a>=0)
                                  a=a;
                               else
                                  a=a+7;
                 switch (a)
                          {
                           case 0:
                                 {
                                  system("color 2");
                                        c=1;
                                           printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                                           printf("                           1   ");
                                         for (i=0;i<5;i++){
                                                 printf("\t\n");
                                         for (j=0;j<7;j++){
                                                c++;
                                          if (c>jourmax)
                                                        break;
                                            printf("%4d",c);
                                          }
                                        }
                                    }
                                          break;
                            case 6:
                                    {
                                     system("color 2");
                                         c=2;
                                   printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                                   printf("                       1   2   ");
                                   for (i=0;i<5;i++){
                                    printf("\t\n");
                                   for (j=0;j<7;j++)
                                     {
                                         c++;
                                        if (c>jourmax)
                                             break;
                                         printf("%4d",c);
                                      }
                                    }
                                   }
                                    break;

                             case 5:{
                                 system("color 2");
                                     c=3;
                                 printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                                 printf("                   1   2   3   ");
                                 for (i=0;i<5;i++)
                                 {
                                  printf("\t\n");
                                for (j=0;j<7;j++){
                                       c++;
                                if (c>jourmax)
                                   break;
                               printf("%4d",c);
                               }
                               }
                               }
                                  break;

                           case 4:
                                 {
                                 system("color 2");
                                        c=4;
                                printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                                printf("               1   2   3   4  ");
                                for (i=0;i<5;i++)
                                {
                                printf("\t\n");
                                for (j=0;j<7;j++)
                                {
                                   c++;
                               if (c>jourmax)
                                break;
                               printf("%4d",c);
                               }
                              }
                              }
                              break;
                          case 3:
                                {
                            system("color 2");
                            system("color 2");
                              c=5;
                            printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                            printf("           1   2   3   4   5   ");
                           for (i=0;i<5;i++)
                            {
                            printf("\t\n");
                           for (j=0;j<7;j++)
                            {
                            c++;
                            if (c>jourmax)
                              break;
                            printf("%4d",c);
                            }
                           }
                        }
                          break;

                    case 2:{
                       system("color 2");
                           c=6;
                       printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                        printf("       1   2   3   4   5   6   ");
                      for (i=0;i<5;i++){
                       printf("\t\n");
                      for (j=0;j<7;j++){
                            c++;
                        if (c>jourmax)
                             break;
                       printf("%4d",c);
                     }
                     }
                     }
                      break;

                case 1:
                      {
                       system("color 2");
                           c=7;
                       printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                     printf("  1   2   3    4   5   6   7   ");
                    for (i=0;i<5;i++){
                     printf("\t\n");
                    for (j=0;j<7;j++){
                           c++;
                    if (c>jourmax)
                          break;
                      printf("%4d",c);
                    }
                    }
                    }
                     break;
                    }
                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 6:do{
                system("cls");
                system("color 0c");
                printf("\n_________________BIENVENUE DANS CALCUL DES MOYENNES GENERALES___________________");
                printf("\t\t ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
                float note, moy,cpt=0, som=0;
                char  rep;
                do{
                printf("saisir une note ");
                while(scanf("%f",&note)!=1){
                printf("\nsaisissez des chiffres");
                getchar();}
                som=som+note;
                cpt=cpt+1;
                printf("voulez vous continuer 0/n?\n");
                rep=getch();
                }while(rep!='n' && rep!='N');
                 moy=som/cpt;
                printf("\nla moyenne de l'eleve est, %f",moy);

                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;/*exo  ok*/
        case 7:do{
                system("cls");
                system("color 0c");

                printf("\n\t______________________CLANDRIER ANNUEL________________________\n\n");
                    int mois,jourmax,annee,jour,m1,a1,as,ns,f,ac=0,a,i,j,c,p;
                system("color c");
                do{
                  printf("\tDonner l'annee: ");
                  while(scanf("%d",&annee)!=1){
                  printf("saiisser des chiffres ");
                  getchar();
                  }
                }
                 while (annee<=0);
                   mois=1;
                 printf("\n\nCALENDRIER MENSUEL:\n\n");
                for(p=1;p<=12;p++){
                     if (mois==2){
                       if (((annee%4==0) && (annee%100!=0)) || ((annee%400==0) && (annee%100==0)))
                          jourmax=29;
                       else
                         jourmax=28;
                    }
                     else
                         {
                         if ((mois==1) || (mois==3) || (mois==5) || (mois==7) || (mois==8) || (mois==10) || (mois==12))
                                   jourmax=31;
                         if ((mois==4) || (mois==6) || (mois==9) || (mois==11))
                                   jourmax=30;
                         }

                             jour=1;
                         if (mois>=3){
                              m1 = mois - 2;
                              a1 = annee;
                              }
                               else
                                   {
                                        m1 = mois + 10;
                                        a1 = annee -1;
                                   }
                                          ns= (a1 / 100);
                                       as= (a1 % 100);
                               f= (jour + as + as/4 - 2*ns + ns/4 + (26*m1-2)/10);
                                  a = (f % 7);

                               if(mois==1)
                                  printf("\tJANVIER/%d\n",annee);
                               if(mois==2)
                                  printf("\n\t FEVRIER/%d\n",annee);
                                if(mois==3)
                                      printf("\n\tMARS/%d\n",annee);
                                if(mois==4)
                                        printf("\n\tAVRIL/%d\n",annee);
                                if(mois==5)
                                 printf("\n\tMAI/%d\n",annee);
                                if(mois==6)
                                 printf("\n\tJUIN/%d\n",annee);
                                if(mois==7)
                                 printf("\n\tJUILLET/%d\n",annee);
                                if(mois==8)
                                  printf("\n\tAOUT/%d\n",annee);
                                if(mois==9)
                                   printf("\n\tSEPTEMBRE/%d\n",annee);
                                if(mois==10)
                                 printf("\n\tOCTOBRE/%d\n",annee);
                                if(mois==11)
                                  printf("\n\tNOVEMBRE/%d\n",annee);
                                if(mois==12)
                                   printf("\n\tDECEMBRE/%d\n",annee);
                                   printf("\n");
                                if (a>=0)
                                        a=a;
                                 else
                                   a=a+7;

                            switch (a)
                                    {
                        case 0:
                              {
                              system("color 2");

                                c=1;
                          printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                          printf("                           1   ");
                         for (i=0;i<5;i++)
                          {
                           printf("\t\n");
                         for (j=0;j<7;j++)
                           {
                                   c++;
                            if (c>jourmax)
                                   break;
                            printf("%4d",c);
                           }
                          }
                         }
                           break;
                                 case 6:
                      {
                         system("color 2");
                           c=2;
                       printf(" LUN MAR MER  JEU VEN SAM DIM\n");
                           printf("                       1   2   ");
                              for (i=0;i<5;i++)
                               {
                              printf("\t\n");
                              for (j=0;j<7;j++)
                                  {
                                  c++;
                              if (c>jourmax)
                                        break;
                                printf("%4d",c);
                               }
                              }
                           }
                               break;

case 5:
     {
         system("color 2");
          c=3;
printf(" LUN MAR MER  JEU VEN SAM DIM\n");
printf("                   1   2   3   ");
for (i=0;i<5;i++)
{
    printf("\t\n");
for (j=0;j<7;j++)
{
c++;
if (c>jourmax)
    break;
printf("%4d",c);
}
}
     }
break;

case 4:
     {
         system("color 2");
       c=4;
printf(" LUN MAR MER  JEU VEN SAM DIM\n");
printf("               1   2   3   4  ");
for (i=0;i<5;i++)
{
    printf("\t\n");
for (j=0;j<7;j++)
{
c++;
if (c>jourmax)
    break;
printf("%4d",c);
}
}
     }
break;
case 3:
    {
system("color 2");
  system("color 2");
       c=5;
printf(" LUN MAR MER  JEU VEN SAM DIM\n");
printf("           1   2   3   4   5   ");
for (i=0;i<5;i++)
{
    printf("\t\n");
for (j=0;j<7;j++)
{
c++;
if (c>jourmax)
    break;
printf("%4d",c);
}
}
     }
break;

case 2:
     {
           system("color 2");
       c=6;
printf(" LUN MAR MER  JEU VEN SAM DIM\n");
printf("       1   2   3   4   5   6   ");
for (i=0;i<5;i++)
{
    printf("\t\n");
for (j=0;j<7;j++)
{
c++;
if (c>jourmax)
    break;
printf("%4d",c);
}
}
     }
break;

case 1:
     {
            system("color 2");
       c=7;
printf(" LUN MAR MER  JEU VEN SAM DIM\n");
printf("  1   2   3    4   5   6   7   ");
for (i=0;i<5;i++)
{
    printf("\t\n");
for (j=0;j<7;j++)
{
c++;
if (c>jourmax)
    break;
printf("%4d",c);
}
}
     }
break;
  }
  mois++;
  }
                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 8:do{
                system("cls");
                system("color 0c");
                int i,choix;
    char rep;
    do{
     system("cls");
     system("color 0C");

     printf("\n\n\n");
    printf("\t\t\t        *MENU TRIANGLES*\n");
    printf("\t\t\t        _______________\n\n");
    printf("\t        _________________________     ________________________         \n");Sleep(300);
    printf("\t*------<                          >-<                          >------*\n");Sleep(300);
    printf("\t|------< 01: TRIANGLE ISOCELE     >-<                          >------|\n");Sleep(300);
    printf("\t|------< 02: TRIANGLE RECTANGLE   >-<                          >------|\n");Sleep(300);
    printf("\t|------< 03: TRIANGLE RECTANGLE   >-<                          >------|\n");Sleep(300);
    printf("\t*------<_________________________ >-< ________________________ >------*\n");Sleep(300);

    printf("\n\n\tPOUR");Sleep(100);printf(" QUITTER");Sleep(100);printf(" CETTE");Sleep(100);printf(" PAGE");Sleep(100);
     printf(" APPUYER");Sleep(100);printf(" SUR");Sleep(100);printf(" ZERO\n\n");Sleep(100);

     printf("\tF");Sleep(100);printf("A");Sleep(100);printf("I");Sleep(100);printf("T");Sleep(100);
     printf("E");Sleep(100);printf("S");Sleep(100);printf(" V");Sleep(100);printf("O");Sleep(100);
     printf("T");Sleep(100);printf("R");Sleep(100);printf("E");Sleep(100);printf(" C");Sleep(100);
     printf("H");Sleep(100);printf("O");Sleep(100);printf("I");Sleep(100);printf("X ");Sleep(100);

    while(scanf("%d",&choix)!=1){
    printf("choisissez parmis ces numero du menu");
    getchar();
    }

    switch(choix){
        case 1:do{
                system("cls");
                system("color 0c");
                printf("\n\t___________________TRIANGLE ISOCELE_____________________\n");Sleep(100);
                printf("\t\t           ****************");

                int base,i,j;
                do{
                 printf("\n\nsaisir la base du triangle\n\n ");
                 while(scanf("%d",&base)!=1){
                 printf("\nsaisir des chiffres ");
                 getchar();
                }
                }while(base%2==0);
                for(i=1;i<=base;i+=2){
                for(j=1;j<=(base-i)/2;j++){
                printf(" ");}
                for(j=1;j<=i;j++){
                printf("*");}
                printf("\n");
                }
                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
       case 2:do{
                system("cls");
                system("color 0c");
                printf("\n\t________________TRIANGLE RECTANGLE A DROITE_________________\n\n");Sleep(100);
                printf("\t\t        ***************************");

                int base,i,j;
                do{
                 printf("\n\nsaisir la base du triangle ");
                 while(scanf("%d",&base)!=1){
                 printf("\nsaisir des chiffres ");
                 getchar();
                 }
                }while(base%2==0);
                 for(i=1;i<=base;i+=2){
                for(j=1;j<=(base-i);j++){
                printf(" ");
                }
                for(j=1;j<=i;j++){
                printf("*");
                }
                printf("\n");
                }
                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
      case 3:do{
                system("cls");
                system("color 0c");
                printf("\n\t_______________TRIANGLE RECTANGLE A GAUCHE________________\n");Sleep(100);
                printf("\t\t       ***************************");
                int base,i,j;
                do{
                 printf("\n\nsaisir la base du triangle ");
                 while(scanf("%d",&base)!=1){
                 printf("\nsaisir des chiffres ");
                 getchar();
                 }
                }while(base%2==0);
                for(i=1;i<=base;i+=2){
                for(j=1;j<=i;j++){
                printf("*");
                }
                printf("\n");
                }
                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

      case 0:
                system("cls");
                printf("\t\t\tMERCI D'AVOIR VISITE NOTRE APPLICATION C\n\n\t\t\tAUREVOIR A LA PROCHAINE!");Sleep(50);
                getch();
                exit(0);
        default:system("cls");
        printf("\n\n\n\t\t\a\a choix invalide,recommencer SVP");
        getch();
        }
         puts("\nvoulez vous continuer?\n ");
                printf("\t\t\tSI OUI ENTREZ 1\n\t\t\tSI NON ENTREZ 2 POUR RETOURNER AU MENU GENERAL ");
                while(scanf("%d",&x)!=1){
                printf("saisir seulement des chiffres ");
                  getchar();
                  }
    }while(x==1);break;
     if(x==2){
     exit(0);
     }
     if(x>=2){do{
         printf("voulez vous recommencer o/n ");
         rep=getch();
     }while(rep!='n' && rep!='N');break;
        }


                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 9:do{
                system("cls");
                system("color 0c");
                printf("\n\t_______________________LE JEU DEVINETTE__________________________\n\n");Sleep(200);

                int nbordi,nbuser,cpt=0;
                srand(time(NULL));
                nbordi=(rand()%(101)+1);
                do{
                printf("\nsaisir un nombre ");
                while(scanf("%d",&nbuser)!=1){
                 printf("\nsaisissez des chiffres ");
                 getchar();}
                if(nbuser!=0){
                if(nbuser<nbordi){
                printf("\nvous avez saisi un petit nombre resseyer ");
                }
                else if(nbuser>nbordi){
                printf("\nvous avez saisi un grand nombre resseyer ");
                }
                    cpt++;
               }
               }while(nbuser!=0&&cpt!=10&&nbordi!=nbuser);
               if(nbordi==nbuser){
               printf("vous avez gagner\n");
               }
               else if(cpt==10){
               printf("vous avez perdu \n");
               }

                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;/*exo ok*/
       case 10:do{
                system("cls");
                system("color 0c");
                printf("\n\t________________________FIBONACCI___________________________\n");

                int fibo,n,n1,n2,i;
                do{
                 printf("\nEntrer un nombre positif ou nul:");
                while(scanf("%d",&n)!=1){
                 printf("\nsaisir seulement des chiffres");
                 getchar();
                 }
                }while(n<0);
                 if(n==0 || n==1){
                 fibo=n;
                  }
                  else{
                   n1=1;
                   n2=0;
                   for(i=0; i<(n-1); i++){
                        fibo=n1+n2;
                        n2=n1;
                        n1=fibo;
                        }
                   }
                   printf("Fibonacci de %d est egale a %d.",n,fibo);

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
       case 11:do{
                system("cls");
                system("color 0c");
                printf("\t\t\t\t\t\t\t\t\n\n_________________________ EQUATION DU PREMIER DEGRE_________________________\n");

                int a,b;
                float x;
                 printf("\nsaisir la valeur a ");
                 while(scanf("%d",&a)!=1){
                 printf("saisissez des chiffres ");
                 getchar();}
                 printf("\nsaisir la valeur b ");
                 while(scanf("%d",&b)!=1){
                 printf("saisissez des chiffres ");
                 getchar();}
                 if(a==0){
                          printf("\npas de solution");
                         }
                 else {
                       x=-b/a;
                      printf("\nla solution est %f",x);
                      }


                printf("\n\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
       case 12:do{
                system("cls");
                system("color 0c");
                printf("\n_____________________BIENVENUE AUX EQUATION DU SECOND DEGRE_____________________\n");

                float a,b,c,x0,x1,x2,delta;
                printf("\nsaisir le premier coefficient de l'equation \n");
                while(scanf("%f",&a)!=1){
                printf("saisir un nombre reel  \n");
                getchar();
                }

                printf("saisir le deuxieme coefficient de l'equation \n");
                while(scanf("%f",&b) !=1){
                printf("saisir un nombre reel \n");
                getchar();
                }

                printf("saisir le troisieme coefficient de l'equation \n");
                while(scanf("%f",&c) !=1){
                printf("saisir un nombre reel \n");
                getchar();
                }

                if(a==0)
                printf("l'equation ne pas du second degre \n");
                else
                   {
                    delta=(b*b-4*a*c);
                   if(delta<0.0)

                    printf("l'equation n'admet pas des solution \n");
                  else if(delta==0){
                   x0=(-b)/(2*a);
                     printf("la solution est x0=%f",x0);
                  }
                   else
                      {
                    x1=(-b+sqrt(delta))/(2*a);
                    x2=(-b-sqrt(delta))/(2*a);
                    printf("les solutions de l'equation sont x1=%f et x2=%f",x1,x2);
                 }
                 }

                printf("\ncontinuer o/n: ");
                rep=getch
                ();
                }while(rep!='n' && rep!='N');break;
       case 13:do{
                system("cls");
                system("color 0c");
                printf("\n-------------------*BIENVENUE DANS LES NOMBRES PARFAITS*------------------------\n");

                int n,s=0,i=1;
                system("color 0c");
                 do{
                printf("\nEntrer un nombre entre 1 et 100: ");
                while(scanf("%d",&n)!=1){
                printf("saisissez des chiffres seulement");
                getchar();
                }
                }while(n<1 || n>100);
                 while(i<n){
                  if(n%i==0){
                        s+=i;
                        }
                        i++;
                 }
                  if(s==n){
                     printf("\n%d est Parfait.\n\n",n);
                     }
                     else{
                          printf("\n%d n'est pas Parfait.\n\n",n);
                          }

                printf("\n\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
       case 14:do{
                system("cls");
                system("color 0c");
                printf("_______________________BIENVENUE DANS LES NOMBRES PREMIERS______________________\n");

                int n,i;
                int prem=1;
                printf("saisir un nombre:\n ");
                while(scanf("%d",&n)!=1){
                printf("veuillez saisir des chiffres");
                getchar();}
                 i=2;
                while(i<n && prem){
                if(n%i==0){
                 prem=0;}

                i=i+1;}

                if(prem)
                printf(" %d est premier",n);
                else{
                printf(" %d n'est pas premier",n);
                }
                printf("\n\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
       case 15:do{
                system("cls");
                system("color 0c");
                printf("\n*-----------------BIENVENUE DANS LES MULTIPLES D'UN NOMBRE---------------------*\n");
                int x,n;
                printf("\nsaisir la valeur: ");
                while(scanf("%d",&n)!=1){
                printf("veuillez saisir des chiffres ");
                getchar();
                }
                for(x=n;x<=1000; x++)
                {if(x%n==0){
                printf("%d ",x);}
                }
                printf("\n\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;/*exo ok*/

        case 0:
                system("cls");
                printf("\t\t\tMERCI D'AVOIR VISITE NOTRE APPLICATION C\n\n\t\t\tAUREVOIR A LA PROCHAINE!");Sleep(50);
                getch();
                exit(0);
        default:system("cls");
              printf("\n\t\tCHOIX INVALIDE VEILLEZ RECOMMENCER SVP!\n ");
             getch();
                }//FIN DU SWITCH
                puts("\nvoulez vous continuer?\n ");
                printf("\t\t\tSI OUI ENTREZ 1\n\t\t\tSI NON ENTREZ 2 POUR RETOURNER AU MENU GENERAL ");
                while(scanf("%d",&y)!=1){
                printf("saisir seulement des chiffres ");
                  getchar();
                  }
    }while(y==1);break;
     if(y==2){
     exit(0);
     }
     if(y>=2){do{
         printf("voulez vous recommencer o/n ");
         rep=getch();
     }while(rep!='n' && rep!='N');break;
        }

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
        case 2:do{
                system("cls");
                system("color 0c");

                int i,choix;
    char rep;
    do{
     system("cls");
     system("color 0C");

     printf("\n\n\t\tB");Sleep(50);
     printf("I");Sleep(60);printf("E");Sleep(60);printf("N");Sleep(50);printf("V");Sleep(60);
     printf("E");Sleep(60);printf("N");Sleep(60);printf("U");Sleep(60);printf("E");Sleep(60);printf(" D");Sleep(60);
     printf("A");Sleep(60);printf("N");Sleep(60);printf("S");Sleep(60);printf(" N");Sleep(60);
     printf("O");Sleep(60);printf("T");Sleep(60);printf("R");Sleep(60);printf("E");Sleep(60);
     printf(" A");Sleep(60);printf("P");Sleep(60);printf("P");Sleep(60);printf("L");Sleep(60);
     printf("I");Sleep(60);printf("C");Sleep(60);printf("A");Sleep(60);printf("T");Sleep(60);
     printf("I");Sleep(60);printf("O");Sleep(60);printf("N");Sleep(60);printf(" M");Sleep(60);
     printf("R");Sleep(60);printf(" &");Sleep(60);printf(" M");Sleep(60);printf("m");Sleep(60);
     printf("e");Sleep(60);


    printf("\n\n\t   ******************MENU DU TABLEAU & MATRICE*********************\n");Sleep(60);
    printf("\t *\t\t     *************************                     * \n");
    printf("\t*     _________________________      _________________________      *\n");Sleep(60);
    printf("\t*    |         TABLEAUX         ><><         MATRICES         |     *\n");Sleep(60);
    printf("\t*    | ________________________ ><>< _________________________|     *\n");Sleep(60);
    printf("\t*    | 01: INITIALIATION        ><><  11: DEVOIR DE L'ALGO    |     *\n");Sleep(60);
    printf("\t*    | 02: TABLEAU AFFICHAGE    ><><  12: INITIALISATION A 0  |     *\n");Sleep(60);
    printf("\t*    | 03: TABLEAU  SOMME       ><><  13: AFFICHAGE A L'ECRAN |     *\n");Sleep(60);
    printf("\t*    | 04: MINIM ET MAXIM       ><><  14: MINIM & MAXIM       |     *\n");Sleep(60);
    printf("\t*    | 05: NOMBRE   OCCURENCE   ><><  15: MATRICE SOMME       |     *\n");Sleep(60);
    printf("\t*    | 06: NBR PAIR ET IMPAIR   ><><  16: MATRICE OCCURENCE   |     *\n");Sleep(60);
    printf("\t*    | 07: TABLEAUX MIROIRS     ><><  17: MATRICE PRODUIT     |     *\n");Sleep(60);
    printf("\t*    | 08: TABLEAUX PALINDROMES ><><  18: MATRICE DIAGONALE   |     *\n");Sleep(60);
    printf("\t*    | 09: TABLEAUX MONOTONIES  ><><                          |     *\n");Sleep(60);
    printf("\t*    | 10: TABLEAUX SUPPRESSION ><><                          |     *\n");Sleep(60);
    printf("\t*    |_________________________ ><>< _________________________|     *\n");Sleep(60);
    printf("\t*    |_________________________ ><>< _________________________|     *\n");Sleep(60);
    printf("\t*                                                                   *\n");Sleep(60);
    printf("\t  ******************************************************************\n\n");Sleep(60);

    printf("\tPOUR");Sleep(100);printf(" QUITTER");Sleep(100);printf(" CETTE");Sleep(100);printf(" PAGE");Sleep(100);
     printf(" APPUYER");Sleep(100);printf(" SUR");Sleep(100);printf(" ZERO\n\n");Sleep(100);

    printf("\tF");Sleep(60);printf("A");Sleep(60);printf("I");Sleep(60);printf("T");Sleep(60);
     printf("E");Sleep(60);printf("S");Sleep(60);printf(" V");Sleep(60);printf("O");Sleep(60);
     printf("T");Sleep(60);printf("R");Sleep(60);printf("E");Sleep(60);printf(" C");Sleep(60);
     printf("H");Sleep(60);printf("O");Sleep(60);printf("I");Sleep(60);printf("X: ");Sleep(60);

    while(scanf("%d",&choix)!=1){
    printf("choisissez parmis ces numero du menu");
    getchar();}

    switch(choix){
          case 1:do{
                system("cls");
                system("color 0c");
                printf("\n\t________________________TABLEAU INITIALISATION____________________\n\n");
                int i,tab[5];
                for(i=0;i<=4;i++){
                tab[i]=0;
                }
                for(i=0;i<=4;i++){
                printf("\t%d",tab[i]);
                }
                printf(" \n\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 2:do{
                system("cls");
                system("color 0c");
                printf("\n\t____________________________TABLEAU AFFICHAGE_________________________\n");

                int tab[5];
                int i;
                puts("saisir les elements de 1 a 5");
                for(i=0;i<5;i++)
                {
                printf("\nsaisir l'element a l'indice %d ",i+1);
                while(scanf("%d",&tab[i])!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                }
                puts("\nvoici votre tableau\n");
                for(i=0;i<5;i++)
                {
                printf("%d   ",tab[i]);
                }

                printf("\n\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 3:do{
                system("cls");
                system("color 0c");



                printf("\n\t________________________TABLEAU SOMME___________________________\n");

                int tab[100];
                int n,i,s=0;
                printf("\nsaisir la taille effective du tableau ");
                while(scanf("%d",&n)!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                for(i=0;i<n;i++){
                printf("\nsaisir l'element a l'indice %d\n ",i+1);
                while(scanf("%d",&tab[i])!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                 s=s+tab[i];
                }
                printf("les elements du tableau sont\n");
                for(i=0;i<n;i++){
                printf("%d\t",tab[i]);
                }
                printf("\nla somme des elements du tableau est %d\n",s);

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 4:do{
                system("cls");
                system("color 0c");
                printf("\n\t_____________________TABLEAU MIN & MAX_______________________\n");

                int tab[100];
                int n,i,max,min=0;
                printf("\nsaisir la taille effective du tableau ");
                while(scanf("%d",&n)!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                for(i=0;i<n;i++){
                printf("\nsaisir l'element a l'indice %d ",i+1);
                while(scanf("%d",&tab[i])!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                }
                printf("\nles elements du tableau sont\n\n ");
                for(i=0;i<n;i++){
                printf("%d\t",tab[i]);
                }
                min=tab[0];
                max=tab[0];
                for(i=0;i<n;i++){
                if(min>tab[i]){
                min=tab[i];
                }
                else if(max<tab[i]){
                 max=tab[i];
                }
                }
                printf("\n\nle maximum est %d et le minimum est %d ",max,min);

                printf("\n\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 5:do{
                system("cls");
                system("color 0c");
                printf("\n\t______________________TABLEAU OCCURENCE_________________________\n");

                char tab[100],C;
                int n,i,cpt=0;
                printf("\nSaisir la taille effective du tableau:");
                while(scanf("%d",&n)!=1){
                printf("\nVeuillez reprendre\n\a");
                getchar();
                }
                for(i=0; i<n; i++){
                printf("\nSaisir l'element a l'indice:");fflush(stdin);
                scanf("%c",&tab[i]);
                }
                printf("\nSaisir le Caractere a rechercher:");fflush(stdin);
                scanf("%c",&C);
                for(i=0; i<n; i++){
                if(tab[i]==C){
                cpt++;
                }
                }
                printf("\nle nombre d'occurrence de %c est %d\n\n",C,cpt);
                for(i=0; i<n; i++){
                printf("  %c",tab[i]);
                }
                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 6:do{
                system("cls");
                system("color 0c");
                printf("\n\t_______________TABLEAU NOMBRES PAIR & IMPAIR___________________\n");


                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;


          case 7:do{
                system("cls");
                system("color 0c");
                printf("\n\t_________________________TABLEAU MIRROIR___________________________\n");

                int i,N1,N2;
                int mirroir=1;
                char mot1[100];
                char mot2[100];
                printf("\nSaisir la taille effective du 1er tableau:");
                while(scanf("%d",&N1)!=1){
                printf("saisir seulement des chiffres");
                getchar();
                }
                for(i=0; i<N1; i++){
                printf("Saisir l'element a l'indice:");
                fflush(stdin);
                scanf("%c",&mot1[i]);
                }/*FIN DE CREATION ET RAMPLISAGE DU 1er TABLEAU*/
                printf("\nSaisir la taille effective du 2eme tableau:");
                while(scanf("%d",&N2)!=1){
                printf("saisir seulement des chiffres");
                getchar();
                }
                for(i=0; i<N2; i++){
                printf("Saisir l'element a l'indice:");
                fflush(stdin);
                scanf("%c",&mot2[i]);/*pr gerer ls chiffres*/
                }/*FIN DE CREATION ET RAMPLISAGE DU 2eme TABLEAU*/
                if(N1!=N2){
                mirroir=0;
                }
                else{
                i=N2;
                for(i=0;i>=0;i--){
                if(mot1[N2-1-i]!=mot2[i]){
                mirroir=0;
                }

                }
                }
                if(mirroir==1){
                printf("les deux mots sont des mirroirs.");
                }
                else{
                printf("les deux mots ne sont pas des mirroirs.");
                }
                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 8:do{
                system("cls");
                system("color 0c");
                printf("\n\t_______________________TABLEAU PALINDROME___________________________\n");

                int N,i,re=1;
                char tab[100];
                printf("\nSaisir la taille effective du tableau: ");
                while(scanf("%d",&N)!=1){
                printf("\nsaisir seulement des chiffres");
                getchar();
                }
                for(i=0;i<N;i++){
                printf("\nSaisir l'element a l'indice ");fflush(stdin);
                scanf("%c",&tab[i]);/*pour gerer ls caractere*/
                }
                 i=0;
               while(i<=N/2 && re==1){
               if(tab[N-1-i]!=tab[i]){
                re=0;
               }
                i++;
               }
               if(re==1){
               printf("\nCe Mot est un palindrome");
               }
               else{
               printf("\nCe Mot n'est pas un palindrome");
               }

                printf("\n\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;


          case 9:do{
                system("cls");
                system("color 0c");
                printf("\n\t______________________TABLEAU MONOTONIE___________________________\n");

                int i,j,cpti=1,cptf=1,n;
                int tab[100];
                printf("\nSaisir la taille effective du tableau: ");
                while(scanf("%d",&n)!=1){
                printf("\nVeuillez reprendre\n\a ");
                getchar();
                }
                for(i=0; i<n; i++){
                printf("\nSaisir l'element a l'indice %d ",i+1);
                while(scanf("%d",&tab[i])!=1){
                    printf("\nVeuillez reprendre\n\a ");
                    getchar();
                        }
               }/*FIN DE CREATION ET RAMPLISAGE DU TABLEAU*/
               for(i=0; i<n; i++){
                j=i+1;
               while(tab[i]<=tab[j] && j<=n){
               cpti=cpti+1;
                i++;
                j++;
               }
                if(cpti>cptf) {
                 cptf=cpti;
                }
                  cpti=1;
               }
                printf("\nLA PLUS GRANDE MONOTONIE CROISSANTE EST DE %d ",cptf);


                printf("\n\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 10:do{
                system("cls");
                system("color 0c");
                printf("\n\t_______________________TABLEAU SUPPRESSION__________________________\n");


                int tab[100],i,j,cpt=0,n;
                printf("\nsaisir la taille effective du tableau:");
                while(scanf("%d",&n)!=1){
                printf("saisir seulement des chiffres");
                getchar();
                }
                for(i=0; i<n; i++){
                printf("\nsaisir l'element a l'indice:",i);
                while(scanf("%d",&tab[i])!=1){
                printf("\nsaisir seulement des chiffres");
                getchar();
                }
                }
                for(i=0; i<n; i++){
                while(tab[i]==1 && i<n){
                for(j=i; j<(n-1); j++){
                tab[j]=tab[j+1];
                    }
                cpt+=1;
                n=n-1;
                }
                }
                printf("le chiffre 1 existe %d fois dans le tableau.",cpt);

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;


          case 11:do{
                system("cls");
                system("color 0c");
                printf("\n\t_____________________DEVOIR ALGO______________________\n");

                int mat[100][100];
    int j,i,k=0,l,c,val,inf,sup,mil,ech;
    int tab[100],diagonal=1,dic=0;
   printf("\nSaisir le nombre de lignes:");
  while(scanf("%d",&l)!=1){
        printf("Veuillez reprendre\n\a");
        getchar();
            }
  printf("\nSaisir le nombre de colonnes:");
  while(scanf("%d",&c)!=1){
          printf("Veuillez reprendre\n\a");
          getchar();
              }
      for(i=0; i<l; i++){
            for(j=0; j<c; j++){
                printf("\nSaisir les elements a l'indice de la matrice:");
                while(scanf("%d",&mat[i][j])!=1){
                    printf("Veuillez reprendre\n\a");
                    getchar();
                        }
            }
      }/*FIN DE CREATION ET RAMPLISAGE DE LA MATRICE*/
    puts("\nAFFICHAGE DE LA MATRICE\n");
    for(i=0;i<l;i++){
        for(j=0;j<l;j++){
            printf("  %d\t",mat[i][j]);
        }
        printf("\n");
    }/*FIN DE LA CREATION ET AFFICHAGE DE LA MATRICE*/

    for(i=0;i<l;i++){
        for(j=0;j<c;j++){
            if(i!=j && mat[i][j]!=0)
            diagonal=0;
        }
    }
    if(diagonal==0){
        printf("\n\nLA MATRICE N'EST PAS DIAGONALE\n");
    for(i=0;i<l;i++)
     for(j=0;j<c;j++)
      if(i!=j)
      mat[i][j]=0;
      puts("\n\nMATRICE DIAGONALISEE\n");
    }
      else{
      printf("\nLA MATRICE EST DIAGONALE\n");
      }
       for(i=0;i<l;i++){
         for(j=0;j<c;j++){
           if(i!=j && mat[i][j]!=0){
          mat[i][j]=0;
               }
                      }
                    }
for(i=0;i<l;i++){
        for(j=0;j<l;j++){
            printf(" %d\t",mat[i][j]);
        }
        printf("\n");
    }
for(i=0;i<l;i++){
    for(j=0;j<c;j++){
        if(i==j)
            tab[i]=mat[i][j];
    }
}
puts("\nNouveau tableau\n");
for(i=0;i<l;i++){
        printf("  %d ",tab[i]);
        }
for(i=0;i<l-1;i++){
    for(j=i+1;j<l;j++){
        if(tab[i]>tab[j]){
            ech=tab[j];
            tab[j]=tab[i];
            tab[i]=ech;
        }
    }
}
puts("\n\nNouveau tableau trier\n");
for(i=0;i<l;i++){
        printf("  %d ",tab[i]);
        }
 printf("\n\n\t\tQUELLE VALEUR VOUDRIEZ-VOUS RECHERCHER! : ");
 scanf("%d",&val);
 inf=0;
 sup=l;
 while(inf<=sup && dic==0){
    mil=(inf+sup)/2;
    if(tab[mil]==val){
        dic=1;
    }
    else if(tab[mil]>val){
        sup=mil-1;
    }
    else
        inf=mil+1;
 }
 if(dic==1){
    printf("\nla valeur %d existe dans le tableau a la position %d.\n",val,mil+1);
 }
 else{
    printf("\nDesolez la valeur %d n'existe pas dans le tableau.\n",val);
 }

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 12:do{
                system("cls");
                system("color 0c");
                printf("\n\t_____________________MATRICE INITIALISATION A 0______________________\n\n");
                int mat[2][5]={{0,0,0,0,0},{0,0,0,0,0}};
                int i,j;

                for(i=0;i<2;i++){
                for(j=0;j<5;j++){
                 printf("\t%d",mat[i][j]);
                }

                  printf("\n\n");

                }
                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 13:do{
                system("cls");
                system("color 0c");
                printf("\n\t_________________________AFFICHASGE A L'ECRAN_______________________\n");

                int mat[100][100],i,l,j,c,f;
                printf("\nsaisir le nombre de ligne de la matrice ");
                while(scanf("%d",&l)!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                printf("\nsaisir le nombre de colonne de la matrice ");
                while(scanf("%d",&c)!=1){
                printf("\nsaisir seulement des chiffres ");
                getchar();
                }
                for(i=0;i<l;i++){
                for(j=0;j<c;j++){
                printf("\nsaisir un nombre ");
                while(scanf("%d",&mat[i][j])!=1){
                printf("saisir seulement des chiffres");
                getchar();
                }
                }
                }
                for(i=0;i<l;i++){
                for(j=0;j<c;j++){
                printf("%d\t",mat[i][j]);
                }
                printf("\n");
                }
                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 14:do{
                system("cls");
                system("color 0c");
                printf("\n\t______________________MATRICE MIN & MAX_______________________\n");

                int i,j,l,c,mi,ma;
                int mat[100][100];
                printf("\nSaisir le nombre de lignes: ");
                while(scanf("%d",&l)!=1){
                printf("\nVeuillez reprendre\n\a");
                getchar();
                }
                printf("\nSaisir le nombre de colonnes: ");
                while(scanf("%d",&c)!=1){
                printf("\nVeuillez reprendre\n\a ");
                getchar();
                }
                for(i=0; i<l; i++){
                for(j=0; j<c; j++){
                printf("\nSaisir les elements a l'indice de la matrice: ");
                while(scanf("%d",&mat[i][j])!=1){
                printf("\nVeuillez reprendre\n\a ");
                getchar();
                }
                }
                }
                         mi=mat[0][0];
                         ma=mat[0][0];
                for(i=0; i<l; i++){
                for(j=0; j<c; j++){
                    if(mi>mat[i][j]){
                       mi=mat[i][j];
                    }
                    else if(ma<mat[i][j]){
                        ma=mat[i][j];
                    }
               }
               }
               printf("\nle Maximum des elements de la matrice est %d et le Minimum est %d.\n",ma,mi);
               for(i=0;i<l;i++){
                for(j=0;j<c;j++){
                printf("%d\t",mat[i][j]);
                }
                printf("\n");
                }

                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;

          case 15:do{
                system("cls");
                system("color 0c");



                printf("\n\t________________________MATRICE SOMME____________________________\n");
                int i,j,l,c;
                          int mat1[100][100],mat2[100][100],mat[100][100];
                              printf("\nSaisir le nombre de ligne: ");
                                    while(scanf("%d",&l)!=1){
                                    printf("Veuillez reprendre\n\a ");
                                    getchar();
                                            }
                              printf("\nSaisir le nombre de colonne: ");
                                    while(scanf("%d",&c)!=1){
                                    printf("Veuillez reprendre\n\a ");
                                    getchar();
                                            }
                             for(i=0; i<l; i++){
                               for(j=0; j<c; j++){
                                  printf("\nSaisir les elements a l'indice de la premiere matrice: ");
                                      while(scanf("%d",&mat1[i][j])!=1){
                                      printf("Veuillez reprendre\n\a ");
                                      getchar();
                                            }
                                  }
                               }
                            for(i=0; i<l; i++){
                              for(j=0; j<c; j++){
                                    printf("\n\nSaisir les elements a l'indice de la deuxieme matrice: ");
                                         while(scanf("%d",&mat2[i][j])!=1){
                                         printf("Veuillez reprendre\n\a ");
                                         getchar();
                                            }
                                                        }
                                                 }
                               for(i=0; i<l; i++){
                                  for(j=0; j<c; j++){
                                     mat[i][j]=mat1[i][j]+mat2[i][j];
                                          }
                                    }
                              printf("\n\nLA SOMME DE LA MATRICE EST:\n");
                                   for(i=0; i<l; i++){
                                         for(j=0; j<c; j++){
                                   printf(" %d\t",mat[i][j]);
                                                  }
                                            printf("\n");
                                         }
                 printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;


          case 16:do{
                system("cls");
                system("color 0c");
                printf("\n\t__________________________MATRICE OCCURENCE________________________\n");

                int i,j,l,c,cpt=0,n;
                int mat[100][100];
                printf("\nSaisir le nombre de lignes:");
                while(scanf("%d",&l)!=1){
                printf("Veuillez reprendre\n\a");
                getchar();
                }
                printf("\nSaisir le nombre de colonnes:");
                while(scanf("%d",&c)!=1){
                printf("Veuillez reprendre\n\a");
                getchar();
                }
                for(i=0; i<l; i++){
                for(j=0; j<c; j++){
                printf("\nSaisir les elements a l'indice de la matrice:");
                while(scanf("%d",&mat[i][j])!=1){
                printf("Veuillez reprendre\n\a");
                getchar();
                        }
                }
                 }/*FIN DE CREATION ET RAMPLISAGE DE LA MATRICE*/
                printf("\n\t\tSAISIR LE NOMBRE A RECHERCHER:");
                while(scanf("%d",&n)!=1){
                    printf("Veuillez reprendre\n\a");
                    getchar();
                        }

                for(i=0; i<l; i++){
                for(j=0; j<c; j++){
                    if(mat[i][j]==n){
                            cpt=cpt+1;
                    }
                }
                }
                printf("\nLE NOMBRE D'OCCURRENCE DE LA VALEUR  %d DANS LA MARTICE EST %d.\n\n",n,cpt);
                for(i=0; i<l; i++){
                for(j=0; j<c; j++){
                printf("  %d",mat[i][j]);
                }
                printf("\n\n");
                }


                printf("\ncontinuer o/n: ");
                rep=getch();
                }while(rep!='n' && rep!='N');break;


          case 17:do{
                system("cls");
                system("color 0c");
                printf("\n\t_________________________MATRICE PRODUIT____________________________\n");

                int i,j,k,L1,C1,L2,C2,som;
                int mat1[100][100],mat2[100][100],mat[100][100];
/*1er matrice*/

                printf("\nSaisir le nombre de lignes de la premiere matrice: ");
                while(scanf("%d",&L1)!=1){
                    printf("\nVeuillez reprendre\n\a ");
                    getchar();
                                            }
                printf("\nSaisir le nombre de colonnes dela premiere matrice: ");
                while(scanf("%d",&C1)!=1){
                                  printf("\nVeuillez reprendre\n\a ");
                                   getchar();
                                            }
                for(i=0; i<L1; i++){
                for(j=0; j<C1; j++){
                printf("\nSaisir les elements a l'indice: ");
                while(scanf("%d",&mat1[i][j])!=1){
                        printf("\nVeuillez reprendre\n\a ");
                        getchar();
                                            }
                }
               }
   /*2eme matrice*/
                      printf("\nSaisir le nombre de lignes de la deuxieme matrice: ");
                      while(scanf("%d",&L2)!=1){
                      printf("\nVeuillez reprendre\n\a");
                      getchar();
                                            }
                      printf("\nSaisir le nombre de colonnes de la deuxieme matrice: ");
                      while(scanf("%d",&C2)!=1){
                      printf("\nVeuillez reprendre\n\a ");
                      getchar();
                                            }
                      for(i=0; i<L2; i++){
                      for(j=0; j<C2; j++){
                      printf("\nSaisir les elements a l'indice: ");
                      while(scanf("%d",&mat2[i][j])!=1){
                                  printf("\nVeuillez reprendre\n\a ");
                                   getchar();
                                            }
                      }
                      }

                      if(C1!=L2){
                        printf("\n\t\t\tERREUR");
                      }
                      else{
                        for(i=0; i<L1; i++){
                        for(j=0; j<C2; j++){
                          som=0;
                        for(k=0; k<C1; k++){
                         som=som+(mat1[i][k]*mat2[k][j]);
                        }
                          mat[i][j]=som;
                        }
                        }

                        printf("\nLE PRODUIT DE LA MATRICE EST:\n");
                        for(i=0; i<L1; i++){
                        for(j=0; j<C1; j++){
                        printf("%d\t",mat[i][j]);
                        }
                        printf("\n");
                        }
                        }

                         printf("\ncontinuer o/n:");
                         rep=getch();
                         }while(rep!='n' && rep!='N');break;




                case 18:do{
                system("cls");
                system("color 0c");
                printf("\n\t_________________________MATRICE DIAGONALE_________________________\n");

                int i,j,l,c,reps=1;
                int mat[100][100];
                printf("\nSaisir le nombre de lignes:");
                while(scanf("%d",&l)!=1){
                printf("Veuillez reprendre\n\a");
                getchar();
                }
                printf("\nSaisir le nombre de colonnes:");
                while(scanf("%d",&c)!=1){
                    printf("Veuillez reprendre\n\a");
                    getchar();
                }
                if(l!=c) {
                printf("\nla matrice doit etre carre");
                }
                 else{
                 for(i=0; i<l; i++){
                  for(j=0; j<c; j++){
                 printf("\nSaisir les elements a l'indice de la matrice:");
                while(scanf("%d",&mat[i][j])!=1){
                    printf("Veuillez reprendre\n\a");
                    getchar();
                        }
                 }
                 }
                 for(i=0;i<l;i++){
                 for(j=0;j<c;j++){
                 if(i!=j && mat[i][j]!=0){
                   reps=0;
                 }
                }
                }
                if(reps==0){
                  printf("\nLA MATRICE N'EST PAS DIAGONALE.\n\n");

                }
                 else{
                 printf("\nLA MATRICE EST DIAGONALE.\n\n");

                }
                }
                for(i=0;i<l;i++){
                 for(j=0;j<c;j++){
                      printf(" %d\t",mat[i][j]);
                }
                    printf("\n");
                 }

                printf("  \ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;
           case 0:
                system("cls");
                printf("\t\t\tMERCI D'AVOIR VISITE NOTRE APPLICATION C\n\n\t\t\tAUREVOIR A LA PROCHAINE!");Sleep(50);
                getch();
                exit(0);
        default:system("cls");
              printf("\n\t\tCHOIX INVALIDE VEILLEZ RECOMMENCER SVP!\n ");
             getch();
                }//FIN DU SWITCH
                puts("\nvoulez vous continuer?\n ");
                printf("\t\t\tSI OUI ENTREZ 1\n\t\t\tSI NON ENTREZ 2 POUR RETOURNER AU MENU GENERAL ");
                while(scanf("%d",&y)!=1){
                printf("saisir seulement des chiffres ");
                  getchar();
                  }
    }while(y==1);break;
     if(y==2){
     exit(0);
     }
     if(y>=2){do{
         printf("voulez vous recommencer o/n ");
         rep=getch();
     }while(rep!='n' && rep!='N');break;
        }

                printf("\ncontinuer o/n:");
                rep=getch();
                }while(rep!='n' && rep!='N');break;


        case 0:
                system("cls");
                printf("\n\n\t -------------------IDENTIFICATION---------------------");Sleep(50);
                printf("\n\t|                                                      |");Sleep(50);
                printf("\n\t|   NOM   : DIALLO                                     |");Sleep(50);
                printf("\n\t|                                     -----------      |");Sleep(50);
                printf("\n\t|   PRENOM: MAMADOU TAHIROU          |  photo    |     |");Sleep(50);
                printf("\n\t|                                    |           |     |");Sleep(50);
                printf("\n\t|   NIVEAU: LICENCE                  |           |     |");Sleep(50);
                printf("\n\t|                                     -----------      |");Sleep(50);
                printf("\n\t|   UNIVERSITE: UDB(bourguiba)                         |");Sleep(50);
                printf("\n\t|                                                      |");Sleep(50);
                printf("\n\t|   MATRICULE: 027                                     |");Sleep(50);
                printf("\n\t|                                                      |");Sleep(50);
                printf("\n\t|   EMAIL    : diallotahirou0@gmail.com                |");Sleep(50);
                printf("\n\t|                                                      |");Sleep(50);
                printf("\n\t|   ADDRESSE:  Sicap(Liberte 2)                        |");Sleep(50);
                printf("\n\t|                                                      |");Sleep(50);
                printf("\n\t|   TEl     :  77344 55 27                             |");Sleep(50);
                printf("\n\t ------------------------------------------------------");Sleep(50);
                printf("\n\t");
                getch();
                exit(0);
        default:system("cls");
        printf("\n\n\n\t\t\a\a choix invalide,recommencer SVP");Sleep(50);
        getch();
        }
    }while(1);
    return 0;

    }

